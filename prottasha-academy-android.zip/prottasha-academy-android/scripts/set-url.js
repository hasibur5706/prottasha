// Writes the real website address (APP_URL) into capacitor.config.json before the build.
const fs = require('fs');
const url = (process.env.APP_URL || '').trim().replace(/\/+$/, '');
if (!/^https:\/\/[^\s/]+/.test(url)) { console.error('APP_URL must be your website address starting with https:// (e.g. https://prottasha.example.com)'); process.exit(1); }
const f = 'capacitor.config.json', c = JSON.parse(fs.readFileSync(f, 'utf8'));
c.server.url = url; fs.writeFileSync(f, JSON.stringify(c, null, 2) + '\n'); console.log('server.url =', url);
