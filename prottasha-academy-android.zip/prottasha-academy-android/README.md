# Prottasha Academy — Android app (Phase 1)

The app is a native Android shell that opens **your real website**, so every page and feature
(exams, OMR, face attendance, CQ, store, admission, admit card, chat, calls, wallet, AI explanation…)
runs on **your real backend and database**. The app never connects to the database directly —
it talks to your website's API (the same one the site uses), which is the secure way.

## 1) Update your website (once)
Copy `website-patch/frontend/css/app-skin.css` and `website-patch/frontend/js/app-shell.js` into your site's
`frontend/css` and `frontend/js`, then apply `website-patch/index-html.patch`
(or add the 3 lines it shows by hand). The skin only switches on inside the app, so the website looks the same as before.

## 2) Build the APK with GitHub (no Android Studio needed)
1. Create a GitHub repository and upload everything in this folder.
2. Repository → Settings → Secrets and variables → Actions → **Variables** → New variable:
   `APP_URL` = your website address, e.g. `https://prottasha.example.com` (must be https).
3. Actions tab → **Build Android APK** → Run workflow.
4. When it finishes, download **prottasha-academy-debug-apk** and install `app-debug.apk` on a phone.

## What is included
- Launcher icon and splash screen from your logo; light status bar.
- Camera / microphone / photo permissions (face attendance, OMR scan, voice, photo answers).
- Offline screen with Retry, "No internet / Back online" toast.
- Android back button: closes menus, goes to Home, blocks leaving a running exam, press twice to exit.
- Logo-colour light glass skin for the in-app look.

## Needs your real server to check
Camera/microphone in the WebView, WebSocket chat and calls, and file upload depend on your server being
served over **https** with a valid certificate. Test these on a real phone after the first build.

## Next phases (not built yet)
Screen-by-screen rebuild of the pages to match the design preview exactly (Home, Exam, Result, Admission…),
push notifications, and a signed release build for Google Play.
