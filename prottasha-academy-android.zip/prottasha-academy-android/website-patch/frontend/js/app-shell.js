/* Prottasha Academy — Android app shell behaviour.
   Runs only inside the Capacitor app (user agent contains "ProttashaApp"); does nothing on the website. */
(function () {
  'use strict';
  var inApp = /ProttashaApp/.test(navigator.userAgent || '') ||
    (window.Capacitor && typeof Capacitor.isNativePlatform === 'function' && Capacitor.isNativePlatform());
  if (!inApp) return;

  var root = document.documentElement;
  root.classList.add('is-app');
  // The app always uses the light glass look.
  root.setAttribute('data-theme', 'light');
  try { localStorage.setItem('theme', 'light'); } catch (e) {}
  new MutationObserver(function () {
    if (root.getAttribute('data-theme') !== 'light') root.setAttribute('data-theme', 'light');
  }).observe(root, { attributes: true, attributeFilter: ['data-theme'] });

  var P = (window.Capacitor && Capacitor.Plugins) || {};
  try { P.StatusBar && P.StatusBar.setStyle && P.StatusBar.setStyle({ style: 'LIGHT' }); } catch (e) {}
  try { P.StatusBar && P.StatusBar.setBackgroundColor && P.StatusBar.setBackgroundColor({ color: '#f3f6ff' }); } catch (e) {}
  try { P.SplashScreen && P.SplashScreen.hide && P.SplashScreen.hide(); } catch (e) {}

  // ---- toast for connection changes ----
  var toastEl;
  function toast(msg, ok) {
    if (toastEl) toastEl.remove();
    toastEl = document.createElement('div');
    toastEl.className = 'app-toast'; toastEl.setAttribute('role', 'status');
    toastEl.style.setProperty('--c', ok ? '#16a34a' : '#e11d48');
    var i = document.createElement('i'); i.textContent = ok ? '✓' : '!';
    var t = document.createElement('span'); t.textContent = msg;
    toastEl.appendChild(i); toastEl.appendChild(t); document.body.appendChild(toastEl);
    var el = toastEl; setTimeout(function () { if (el.parentNode) el.remove(); }, 3500);
  }
  window.appToast = toast;
  window.addEventListener('offline', function () { toast('No internet connection', false); });
  window.addEventListener('online', function () { toast('Back online', true); });

  // ---- Android back button ----
  var lastBack = 0;
  function click(sel) { var el = document.querySelector(sel); if (el) { el.click(); return true; } return false; }
  if (P.App && P.App.addListener) {
    P.App.addListener('backButton', function () {
      if (document.body.classList.contains('exam-mode')) { toast('Finish or submit the exam first', false); return; }  // never leave a running exam by accident
      if (document.querySelector('.mn-drawer.open') && click('.mn-overlay')) return;
      var open = document.querySelector('dialog[open], [role="dialog"]:not([hidden]), .modal.open, .ui-dialog.open');
      if (open) { var x = open.querySelector('[data-close],.close,button[aria-label="Close"]'); if (x) { x.click(); return; } }
      var on = document.querySelector('.mn-tab.on');
      if (on && on.getAttribute('data-tab') !== 'overview' && click('[data-tab="overview"]')) return;
      var now = Date.now();
      if (now - lastBack < 1800) { P.App.exitApp && P.App.exitApp(); } else { lastBack = now; toast('Press back again to exit', true); }
    });
  }
})();
