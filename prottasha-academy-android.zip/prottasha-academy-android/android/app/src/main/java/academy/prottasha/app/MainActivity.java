package academy.prottasha.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
